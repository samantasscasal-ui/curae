# Security Specification for Curae

## Data Invariants
- A SleepLog must belong to a valid User and have a non-negative duration.
- Users can only read and write their own logs (Sleep, Nutrition, Assessments).
- User profile data is restricted to the owner for write access.

## The "Dirty Dozen" Payloads (Examples to Reject)
1. **Identity Spoofing**: Attempt to create a sleep log for `userId: "target_user_id"` while authenticated as `victim_user_id`.
2. **State Poisoning**: Inject a 2.0MB string into the `notes` field of a nutrition log.
3. **Invalid Type**: Send `hours: "eight"` instead of `hours: 8` in a sleep log.
4. **Time Spoofing**: Provide a `createdAt` timestamp from 2005.
5. **Orphaned Writes**: Create an assessment for a non-existent user.
6. **Key Injection**: Add a `isVerified: true` hidden field to a User document.
7. **Cross-User Read**: Attempt to list all assessments in the collection.
8. **Negative Metrics**: Log `hours: -5` for sleep.
9. **Invalid Range**: Score an assessment with `score: 150` (assuming 0-100).
10. **Unauthenticated Read**: Attempt to read any document without login.
11. **Malicious ID**: Use document ID `../../system/root` for a log.
12. **PII Leak**: Non-admin attempts to read `/users/{otherUserId}`.

## Test Cases (Implicit in Rules Logic)
- `isValidId(userId)`
- `isValidSleepLog(incoming())`
- `resource.data.userId == request.auth.uid`
