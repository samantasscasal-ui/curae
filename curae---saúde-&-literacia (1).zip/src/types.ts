export type Section = 
  | 'onboarding'
  | 'login'
  | 'home' 
  | 'curae' 
  | 'motus' 
  | 'gladius-setup' 
  | 'gladius' 
  | 'metrics' 
  | 'profile'
  | 'community'
  | 'search'
  | 'menu'
  | 'scouting'
  | 'gdpr'
  | 'injuries'
  | 'check-prevention'
  | 'performance'
  | 'nutrition'
  | 'recovery'
  | 'health'
  | 'young-athletes'
  | 'mindset'
  | 'planning'
  | 'progress'
  | 'parents';

export type UserRole = 'atleta' | 'encarregado';
export type LifeStage = 'materna' | 'idoso' | 'adulto' | 'crianca' | 'recem-nascido';
export type Weapon = 'espada' | 'sabre' | 'florete';
export type Laterality = 'esquerdo' | 'direito';

export interface FencingBout {
  id: string;
  date: string;
  opponent: string;
  weapon: Weapon;
  score: { us: number; them: number };
  result: 'W' | 'L';
  durationSeconds: number;
  actions: {
    attack: number;
    riposte: number;
    counter: number;
    remise: number;
  };
  notes: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  type: 'treino' | 'competição' | 'estágio' | 'outro';
  date: string;
  location?: string;
  notes?: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  date: string;
  icon: string;
  type: 'medal' | 'milestone' | 'congratulations';
}

export interface Goal {
  id: string;
  title: string;
  target: string;
  deadline: string;
  progress: number; // 0-100
}

export interface UserMetrics {
  role: UserRole;
  gdprAccepted: boolean;
  events?: CalendarEvent[];
  sleep: {
    hours: number;
    quality: number; // 1-5
  };
  nutrition: {
    water: number;
    calories?: number;
    mealsCount: number;
  };
  fencing: {
    weapon?: Weapon;
    hand?: Laterality;
    bouts: FencingBout[];
    trainingStats: {
      count: number;
      totalDurationMinutes: number;
    };
  };
  assessments: {
    date: string;
    score: number;
    type: 'gladius' | 'motus';
  }[];
  biometrics: {
    height: { value: number; date: string }[];
    weight: { value: number; date: string }[];
  };
  mood: {
    score: number; // 1-5
    date: string;
  }[];
  goals: Goal[];
  achievements: Achievement[];
}
