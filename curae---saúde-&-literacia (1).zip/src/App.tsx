/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths,
  parseISO
} from 'date-fns';
import { pt } from 'date-fns/locale';
import { 
  Home, 
  Search, 
  Users, 
  User, 
  Menu,
  ChevronRight,
  ChevronLeft,
  Droplets,
  Moon,
  Apple,
  Sword,
  Activity,
  Plus,
  ArrowRight,
  Shield,
  Clock,
  Video,
  Target,
  FileText,
  Zap,
  Brain,
  Coffee,
  Heart,
  Baby,
  Calendar,
  BarChart3,
  Dumbbell,
  Lightbulb,
  Trash2,
  Ruler,
  Scale,
  Trophy,
  Medal,
  Utensils,
  Smile,
  Meh,
  Frown,
  TrendingUp,
  Award,
  X,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged, User as FirebaseUser, signOut } from 'firebase/auth';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer 
} from 'recharts';
import { auth, signIn } from './firebase';
import { cn } from './lib/utils';
import { Section, LifeStage, Weapon, Laterality, UserRole, FencingBout, CalendarEvent, Goal, Achievement } from './types';

const DashboardCard = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  color = "brand-green", 
  onClick 
}: { 
  title: string, 
  value?: string, 
  subtitle?: string, 
  icon: any, 
  color?: string,
  onClick?: () => void
}) => (
  <button 
    onClick={onClick}
    className="card-clean bg-neutral-900/30 border-neutral-800/50 p-5 flex flex-col text-left transition-all active:scale-[0.98]"
  >
    <div className="flex justify-between items-start mb-4">
      <div className={cn("p-2 rounded-xl bg-opacity-20", `bg-${color}`, `text-${color}`)}>
        <Icon size={20} />
      </div>
      {value && <span className="text-xl font-bold text-white">{value}</span>}
    </div>
    <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-1">{title}</h3>
    {subtitle && <p className="text-[10px] text-neutral-500 uppercase tracking-tighter">{subtitle}</p>}
  </button>
);

const SectionHero = ({ title, subtitle, icon: Icon, color = "text-brand-green" }: { title: React.ReactNode, subtitle: string, icon: any, color?: string }) => (
  <header className="mb-10">
    <div className="flex items-center gap-3 mb-2">
      <Icon className={color} size={24} />
      <p className={cn("font-bold text-[10px] uppercase tracking-[0.4em]", color)}>{subtitle}</p>
    </div>
    <h2 className="text-4xl font-serif text-white italic tracking-tighter leading-tight">{title}</h2>
  </header>
);

const MOTIVATIONAL_QUOTES = [
  "O único assalto que perdes é o que não dás.",
  "Mente de campeão: resiliência em cada toque.",
  "O treino de hoje é a vitória de amanhã.",
  "Na dúvida, finta e ataca.",
  "Respeita o teu corpo, ele é a tua arma mais valiosa.",
  "Consistência vence o talento quando o talento não treina."
];
const PrototypeLogo = ({ size = "lg", header = false }: { size?: "sm" | "md" | "lg", header?: boolean }) => {
  const logoUrl = "/input_file_0.png"; 
  return (
    <div className={cn(
      "flex flex-col items-center w-full", 
      header ? "py-8 border-y border-neutral-900 bg-neutral-950/40 backdrop-blur-md" : size === "lg" ? "mb-10" : "mb-4"
    )}>
      <motion.img 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        src={logoUrl} 
        alt="Curae Logo" 
        className={cn(
          "object-contain mix-blend-screen", // Using mix-blend-screen to help with the dark background if needed
          size === "lg" ? "w-72" : size === "md" ? "w-56" : "w-40"
        )} 
        referrerPolicy="no-referrer" 
      />
    </div>
  );
};

const BottomNav = ({ current, onChange }: { current: Section, onChange: (s: Section) => void }) => {
  const items = [
    { id: 'home', icon: Home },
    { id: 'search', icon: Search },
    { id: 'community', icon: Users },
    { id: 'profile', icon: User },
    { id: 'menu', icon: Menu },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-xl z-50 flex justify-between items-center px-10 py-3 border-t border-neutral-900">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = current === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id as Section)}
            className={cn(
              "transition-all duration-300",
              isActive ? "text-brand-green" : "text-neutral-600"
            )}
          >
            <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
          </button>
        );
      })}
    </nav>
  );
};

// --- PAGES ---

const OnboardingPage = ({ onNext }: { onNext: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onNext();
    }, 2500);
    return () => clearTimeout(timer);
  }, [onNext]);

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8">
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="flex flex-col items-center gap-4"
      >
        <PrototypeLogo size="lg" />
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="flex items-center gap-2"
        >
          <div className="w-1.5 h-1.5 bg-brand-green rounded-full animate-pulse" />
          <p className="text-[10px] text-neutral-600 uppercase tracking-[0.6em] font-bold">Iniciando</p>
        </motion.div>
      </motion.div>
    </div>
  );
};

const LoginPage = ({ onLogin, onRoleChange }: { onLogin: () => void, onRoleChange: (r: UserRole) => void }) => {
  const [role, setRole] = useState<UserRole>('atleta');

  const handleQuickLogin = () => {
    onRoleChange(role);
    onLogin();
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-10 font-sans">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12"
      >
        <PrototypeLogo size="md" />
      </motion.div>
      
      <div className="w-full max-w-sm space-y-10">
        <div className="text-center">
          <h1 className="text-3xl font-serif text-white italic tracking-tight mb-3">Bem-vindo(a)</h1>
          <p className="text-[10px] text-neutral-500 uppercase tracking-[0.3em] font-medium">Selecione o seu perfil de acesso</p>
        </div>

        <div className="flex bg-neutral-900/30 border border-neutral-800/40 p-1.5 rounded-2xl mb-8">
          {(['atleta', 'encarregado'] as UserRole[]).map((r) => (
            <button
              key={r}
              onClick={() => { setRole(r); onRoleChange(r); }}
              className={cn(
                "flex-1 py-3.5 text-[9px] font-bold uppercase tracking-widest rounded-xl transition-all duration-500",
                role === r ? "bg-white text-black shadow-xl" : "text-neutral-600 hover:text-neutral-400"
              )}
            >
              {r === 'atleta' ? 'Atleta' : 'Encarregado (Pais)'}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          <button 
            onClick={onLogin} 
            className="group w-full h-16 bg-white hover:bg-neutral-100 text-black font-bold flex items-center justify-center gap-4 rounded-3xl transition-all active:scale-[0.98] shadow-2xl shadow-white/5 overflow-hidden relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="Google" />
            <span className="text-[11px] uppercase tracking-[0.2em]">Entrar com Google</span>
          </button>

          <button 
            onClick={handleQuickLogin}
            className="w-full h-16 bg-neutral-900 border border-neutral-800 text-white font-bold flex items-center justify-center rounded-3xl transition-all hover:bg-neutral-800 active:scale-[0.98]"
          >
            <span className="text-[11px] uppercase tracking-[0.2em]">Entrar como {role === 'atleta' ? 'Atleta' : 'Pai/Mãe'}</span>
          </button>
        </div>

        <div className="pt-6 text-center">
          <button className="text-neutral-800 text-[9px] font-bold uppercase tracking-[0.4em] hover:text-neutral-600 transition-colors">
            Apoio ao Utilizador
          </button>
        </div>
      </div>

      <div className="mt-auto pt-10 opacity-30">
        <p className="text-[8px] text-white uppercase tracking-[0.5em] font-bold">Curae System</p>
      </div>
    </div>
  );
};

const GDPRPage = ({ onAccept }: { onAccept: () => void }) => (
  <div className="min-h-screen bg-black flex flex-col p-10 pt-20">
    <Shield className="text-brand-green mb-6" size={48} />
    <h2 className="text-3xl font-serif text-white italic mb-6">Privacidade e RGPD</h2>
    <div className="card-clean bg-neutral-900/50 flex-1 overflow-y-auto mb-8 space-y-4">
      <p className="text-sm text-neutral-400 leading-relaxed">
        Na Curae, levamos a sério a sua privacidade. Para lhe fornecer métricas detalhadas e acompanhamento personalizado, precisamos de processar os seus dados de saúde e desempenho.
      </p>
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest">Os seus dados serão usados para:</h3>
        <ul className="text-xs text-neutral-500 space-y-2 list-disc pl-4 italic">
          <li>Cálculo de métricas de performance (Gladius/Motus)</li>
          <li>Acompanhamento de hidratação e sono</li>
          <li>Relatórios personalizados para atletas e encarregados</li>
        </ul>
      </div>
      <p className="text-xs text-neutral-600">
        Poderá revogar o seu consentimento a qualquer momento nas definições de perfil. Os seus dados são encriptados e nunca partilhados com terceiros sem autorização expressa.
      </p>
    </div>
    <button onClick={onAccept} className="btn-prototype w-full">Aceitar e Continuar</button>
  </div>
);

const HomePage = ({ onNavigate, role, userName }: { onNavigate: (s: Section) => void, role: UserRole, userName: string }) => {
  return (
    <div className="min-h-screen bg-black flex flex-col pb-32">
      <PrototypeLogo header />
      
      <div className="px-10 pt-10 flex-1 flex flex-col justify-center">
        <div className="text-center mb-12">
          <p className="text-[10px] text-brand-green font-bold uppercase tracking-[0.4em] mb-4">Painel de Controlo</p>
          <h2 className="text-3xl font-serif text-white italic tracking-tighter leading-none mb-2">{userName}</h2>
          <p className="text-[8px] text-neutral-600 uppercase tracking-[0.3em] font-bold">Escolha o seu Percurso</p>
        </div>

        <div className="grid grid-cols-1 gap-6 mb-12">
          <button 
            onClick={() => onNavigate('curae')}
            className="group relative w-full h-32 bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden active:scale-[0.98] transition-all"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-brand-green/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative h-full flex flex-col items-center justify-center gap-2">
              <span className="text-2xl font-serif text-white italic tracking-tight">Curae</span>
              <span className="text-[10px] text-neutral-500 uppercase tracking-[0.3em]">Bem-estar & Saúde</span>
            </div>
          </button>

          <button 
            onClick={() => onNavigate('motus')}
            className="group relative w-full h-32 bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden active:scale-[0.98] transition-all"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-brand-green/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative h-full flex flex-col items-center justify-center gap-2">
              <span className="text-2xl font-serif text-white italic tracking-tight text-brand-green">Curae Motus</span>
              <span className="text-[10px] text-neutral-500 uppercase tracking-[0.3em]">Performance & Treino</span>
            </div>
          </button>
        </div>

        {role === 'encarregado' && (
          <button 
            onClick={() => onNavigate('parents')}
            className="w-full h-20 bg-brand-green/5 border border-brand-green/20 flex items-center justify-center gap-4 rounded-3xl active:scale-[0.98] transition-all group"
          >
            <Users className="text-brand-green shrink-0" size={20} />
            <div className="text-left">
              <span className="text-[10px] font-bold text-white uppercase tracking-widest block">Área dos Pais</span>
              <span className="text-[8px] text-neutral-500 uppercase tracking-widest">Apoio & Mentoria</span>
            </div>
            <ChevronRight className="text-neutral-700 group-hover:text-brand-green transition-colors" size={16} />
          </button>
        )}
      </div>
    </div>
  );
};

const NutritionPage = ({ onBack }: { onBack: () => void }) => (
  <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto">
    <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2 active:scale-95 transition-transform">
      <ChevronLeft size={20} /> <span className="text-[10px] uppercase font-bold tracking-widest">Painel</span>
    </button>
    <SectionHero title={<>Nutrição <span className="text-orange-500">Atlética</span></>} subtitle="Performance & Saúde" icon={Apple} color="text-orange-500" />
    
    <div className="space-y-6">
      <div className="card-clean border-neutral-800">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-4">Combos Pré-Treino</h3>
        <div className="space-y-3">
          {[
            { name: 'Energia Rápida', desc: 'Banana + Mel + Canela', time: '30 min antes' },
            { name: 'Sustentação', desc: 'Pão Integral + Queijo Fresco', time: '1h30 antes' },
            { name: 'Hidratação+', desc: 'Água de Coco + Sal mineral', time: 'Durante' }
          ].map((item, i) => (
            <div key={i} className="flex justify-between items-center p-3 bg-neutral-900 rounded-xl border border-neutral-800">
              <div>
                <p className="text-[10px] font-bold text-white uppercase tracking-tighter">{item.name}</p>
                <p className="text-[9px] text-neutral-500 uppercase">{item.desc}</p>
              </div>
              <span className="text-[8px] text-orange-500 font-bold uppercase tracking-widest">{item.time}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card-clean border-neutral-800">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-4">Protocolo Competição</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Pequeno Almoço', val: 'Carbo Complexo' },
            { label: 'Entre Bouts', val: 'Géis / Isotónico' },
            { label: 'Almoço Leve', val: 'Massa / Arroz' },
            { label: 'Recuperação', val: 'Proteína + Carbo' }
          ].map(s => (
            <div key={s.label} className="p-3 bg-neutral-900 rounded-xl text-center">
              <span className="text-[8px] text-neutral-500 uppercase block mb-1">{s.label}</span>
              <span className="text-[10px] font-bold text-orange-400 italic uppercase">{s.val}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card-clean border-orange-500/20 bg-orange-500/5">
        <div className="flex items-center gap-2 mb-4">
          <Droplets className="text-orange-500" size={18} />
          <h3 className="text-xs font-bold text-white uppercase tracking-widest">Hidratação Inteligente</h3>
        </div>
        <p className="text-xs text-neutral-400 leading-relaxed italic">
          O peso perdido no treino deve ser reposto em 150%. Se perdeste 1kg, bebe 1.5L de água nas horas seguintes.
        </p>
      </div>

      <div className="card-clean border-neutral-800">
        <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-4">Suplementação Base (Jovens)</h3>
        <p className="text-[10px] text-neutral-500 leading-relaxed uppercase tracking-tighter mb-4">Priorize comida real. Suplementos são o topo da pirâmide.</p>
        <ul className="space-y-2">
          {['Multivitamínico (em fases de carga)', 'Ômega 3 (Inflamação)', 'Vitamina D (Inverno)'].map(s => (
            <li key={s} className="flex items-center gap-2 text-[10px] text-neutral-400 font-bold uppercase">
              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full" /> {s}
            </li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

const MindsetPage = ({ onBack }: { onBack: () => void }) => {
  const [breathing, setBreathing] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'In' | 'Hold' | 'Out' | 'Hold2'>('In');

  useEffect(() => {
    let interval: any;
    if (breathing) {
      interval = setInterval(() => {
        setBreathPhase(prev => {
          if (prev === 'In') return 'Hold';
          if (prev === 'Hold') return 'Out';
          if (prev === 'Out') return 'Hold2';
          return 'In';
        });
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [breathing]);

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
        <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
      </button>
      <SectionHero title={<>Fortaleza <span className="text-purple-400">Mental</span></>} subtitle="Mente de Campeão" icon={Brain} color="text-purple-400" />
      
      <div className="space-y-6">
        <div className="card-clean border-purple-500/30 bg-purple-500/5 text-center p-8">
           <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Técnica da Caixa (4-4-4-4)</h3>
           <div className="relative flex items-center justify-center h-32 mb-8">
             <motion.div 
               animate={{ 
                 scale: breathing ? (breathPhase === 'In' || breathPhase === 'Hold' ? 1.5 : 1) : 1,
                 opacity: breathing ? 1 : 0.5
               }}
               transition={{ duration: 4, ease: "linear" }}
               className="w-20 h-20 bg-purple-500/20 border-2 border-purple-500 rounded-2xl flex items-center justify-center"
             >
               <span className="text-xs font-bold text-white uppercase">{breathing ? breathPhase : 'Parado'}</span>
             </motion.div>
           </div>
           <button 
             onClick={() => setBreathing(!breathing)}
             className="w-full py-4 bg-purple-500 text-white font-bold uppercase tracking-widest text-[10px] rounded-xl shadow-xl shadow-purple-500/10 active:scale-95 transition-all"
           >
             {breathing ? 'Parar Exercício' : 'Iniciar Respiração'}
           </button>
        </div>

        <div className="space-y-4">
          {[
            { title: 'Foco no Próximo Toque', desc: 'Esquece o erro anterior, foca no agora.', icon: Target },
            { title: 'Visualização Criativa', desc: 'Imagina o sucesso antes da ação.', icon: Lightbulb },
            { title: 'Diálogo Interno', desc: 'Substitui "não consigo" por "Vou tentar".', icon: MessageSquare }
          ].map((item, i) => (
            <div key={i} className="card-clean border-neutral-800 flex items-start gap-4 p-5 bg-neutral-900/10">
               <item.icon className="text-purple-400 shrink-0" size={20} />
               <div>
                 <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-1">{item.title}</h4>
                 <p className="text-xs text-neutral-500">{item.desc}</p>
               </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const RecoveryPage = ({ onBack }: { onBack: () => void }) => {
  const [sleepLog, setSleepLog] = useState([
    { day: 'Seg', hours: 7.5, quality: 'Bom' },
    { day: 'Ter', hours: 8.2, quality: 'Excelente' },
    { day: 'Qua', hours: 6.8, quality: 'Médio' },
    { day: 'Qui', hours: 8.0, quality: 'Bom' },
  ]);

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
        <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
      </button>
      <SectionHero title={<>O Teu <span className="text-blue-400">Combustível</span></>} subtitle="Sono & Recuperação" icon={Moon} color="text-blue-400" />
      
      <div className="space-y-6">
        <div className="card-clean border-neutral-800">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest">Log Semanal</h3>
            <button className="text-[8px] font-bold text-blue-400 uppercase tracking-widest">+ Registar Noite</button>
          </div>
          <div className="flex justify-between items-end h-24 gap-2 mb-4">
            {sleepLog.map(log => (
              <div key={log.day} className="flex-1 flex flex-col items-center gap-2">
                <div 
                  className="w-full bg-blue-400/20 border border-blue-400/40 rounded-t-lg transition-all"
                  style={{ height: `${(log.hours / 10) * 100}%` }}
                />
                <span className="text-[8px] text-neutral-500 font-bold uppercase">{log.day}</span>
              </div>
            ))}
          </div>
          <div className="p-4 bg-blue-400/5 rounded-xl border border-blue-400/10 text-center">
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest">Média: 7.6h / Noite</p>
          </div>
        </div>

        <div className="card-clean border-neutral-800">
          <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-4">Higiene do Sono</h3>
          <p className="text-[10px] text-neutral-400 mb-6 uppercase tracking-tight">Mínimo 8h para atletas em crescimento.</p>
          <div className="flex gap-4">
            <div className="flex-1 bg-neutral-900 p-4 rounded-xl text-center">
              <span className="text-[8px] text-neutral-500 uppercase block mb-1">Ecrãs</span>
              <span className="text-[10px] font-bold text-blue-400 italic uppercase">Off 1h antes</span>
            </div>
            <div className="flex-1 bg-neutral-900 p-4 rounded-xl text-center">
              <span className="text-[8px] text-neutral-500 uppercase block mb-1">Ambiente</span>
              <span className="text-[10px] font-bold text-blue-400 italic uppercase">Frio & Escuro</span>
            </div>
          </div>
        </div>

        <div className="card-clean border-red-500/20 bg-red-500/5">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="text-red-500" size={16} />
            <h4 className="text-[10px] font-bold text-red-500 uppercase tracking-widest">Sinais de Overtraining</h4>
          </div>
          <p className="text-[10px] text-neutral-400 uppercase italic">Cansaço matinal, perda de apetite, batimento elevado em repouso.</p>
        </div>
      </div>
    </div>
  );
};

const PORTUGAL_DISTRICTS = [
  { name: 'Viana do Castelo', x: 25, y: 15 },
  { name: 'Braga', x: 35, y: 25 },
  { name: 'Vila Real', x: 55, y: 30 },
  { name: 'Bragança', x: 85, y: 15 },
  { name: 'Porto', x: 28, y: 45 },
  { name: 'Aveiro', x: 25, y: 75 },
  { name: 'Viseu', x: 55, y: 70 },
  { name: 'Guarda', x: 80, y: 80 },
  { name: 'Coimbra', x: 35, y: 105 },
  { name: 'Castelo Branco', x: 75, y: 125 },
  { name: 'Leiria', x: 25, y: 135 },
  { name: 'Santarém', x: 45, y: 165 },
  { name: 'Portalegre', x: 85, y: 165 },
  { name: 'Lisboa', x: 25, y: 195 },
  { name: 'Setúbal', x: 35, y: 225 },
  { name: 'Évora', x: 75, y: 220 },
  { name: 'Beja', x: 65, y: 270 },
  { name: 'Faro', x: 65, y: 320 },
  { name: 'Madeira', x: -20, y: 300 }, // Inset-like
  { name: 'Açores', x: -20, y: 250 }  // Inset-like
];

const PortugalMap = ({ events }: { events: CalendarEvent[] }) => {
  const getEventCount = (district: string) => {
    return events.filter(e => e.location === district && e.type === 'competição').length;
  };

  return (
    <div className="relative w-full aspect-[1/2] max-w-[200px] mx-auto bg-neutral-900/40 rounded-3xl p-6 border border-neutral-800/50 mb-10 overflow-hidden">
      <div className="absolute top-4 left-4">
        <p className="text-[8px] font-bold text-neutral-500 uppercase tracking-widest">Mapa de Provas</p>
      </div>
      <svg viewBox="-40 0 160 360" className="w-full h-full fill-none">
        {/* Portugal Simplified Path */}
        <path 
          d="M10,10 L100,10 L110,100 L110,200 L90,340 L40,340 L10,300 L10,200 Z" 
          className="fill-neutral-900/50 stroke-neutral-800" 
          strokeWidth="0.5" 
        />
        
        {PORTUGAL_DISTRICTS.map((d) => {
          const count = getEventCount(d.name);
          return (
            <g key={d.name}>
              <circle 
                cx={d.x} 
                cy={d.y} 
                r={count > 0 ? 3 : 1} 
                className={cn(
                  "transition-all duration-500",
                  count > 0 ? "fill-red-500 shadow-[0_0_10px_red]" : "fill-neutral-700"
                )} 
              />
              {count > 0 && (
                <circle 
                  cx={d.x} 
                  cy={d.y} 
                  r={6} 
                  className="fill-red-500/20 animate-ping" 
                />
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

const PlanningPage = ({ onBack, events, onAddEvent, onRemoveEvent }: { onBack: () => void, events: CalendarEvent[], onAddEvent: (e: Omit<CalendarEvent, 'id'>) => void, onRemoveEvent: (id: string) => void }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newType, setNewType] = useState<CalendarEvent['type']>('treino');
  const [newLocation, setNewLocation] = useState('');
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDate) return;
    onAddEvent({ title: newTitle, date: newDate, type: newType, location: newLocation });
    setNewTitle('');
    setNewDate('');
    setNewLocation('');
    setShowAdd(false);
  };

  const getEventIcon = (type: CalendarEvent['type']) => {
    switch (type) {
      case 'treino': return <Dumbbell size={14} />;
      case 'competição': return <Target size={14} />;
      case 'estágio': return <Users size={14} />;
      default: return <Calendar size={14} />;
    }
  };

  const getDayEvents = (day: Date) => {
    return events.filter(e => isSameDay(parseISO(e.date), day));
  };

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto">
      <div className="flex justify-between items-start mb-8">
        <button onClick={onBack} className="text-neutral-500 flex items-center gap-2">
          <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
        </button>
        <button onClick={() => setShowAdd(!showAdd)} className={cn("p-3 rounded-full transition-all", showAdd ? "bg-red-500/10 text-red-500" : "bg-yellow-500/10 text-yellow-500")}>
          <Plus size={20} className={cn("transition-transform", showAdd && "rotate-45")} />
        </button>
      </div>

      <SectionHero title={<>Agenda da <span className="text-yellow-500">Época</span></>} subtitle="Planeamento" icon={Calendar} color="text-yellow-500" />

      {/* Calendar Grid */}
      <div className="card-clean border-neutral-800 bg-neutral-900/20 mb-8 p-4">
        <div className="flex justify-between items-center mb-6 px-2">
          <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="text-neutral-500 hover:text-white p-1">
            <ChevronLeft size={16} />
          </button>
          <h3 className="text-xs font-bold text-white uppercase tracking-widest">
            {format(currentMonth, 'MMMM yyyy', { locale: pt })}
          </h3>
          <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="text-neutral-500 hover:text-white p-1">
            <ChevronRight size={16} />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-px mb-2 text-center">
          {['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map(d => (
            <span key={d} className="text-[9px] text-neutral-600 font-bold uppercase py-2">{d}</span>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((day, i) => {
            const dayEvents = getDayEvents(day);
            const isSelectedMonth = isSameMonth(day, monthStart);
            const isToday = isSameDay(day, new Date());
            
            return (
              <div 
                key={i} 
                className={cn(
                  "aspect-square rounded-lg flex flex-col items-center justify-center relative transition-all",
                  !isSelectedMonth ? "opacity-20" : "opacity-100",
                  isToday ? "bg-white/5 border border-white/20" : "hover:bg-white/5"
                )}
              >
                <span className={cn(
                  "text-[10px] font-medium",
                  dayEvents.length > 0 ? "text-yellow-500 font-bold" : "text-neutral-400"
                )}>
                  {format(day, 'd')}
                </span>
                
                {dayEvents.length > 0 && (
                  <div className="flex gap-0.5 mt-0.5">
                    {dayEvents.slice(0, 3).map((e, idx) => (
                      <div 
                        key={idx} 
                        className={cn(
                          "w-1 h-1 rounded-full",
                          e.type === 'competição' ? "bg-red-500" : 
                          e.type === 'treino' ? "bg-yellow-500" : "bg-neutral-500"
                        )} 
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {showAdd && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="card-clean border-yellow-500/20 bg-yellow-500/5 mb-8 p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-[10px] text-yellow-500 font-bold uppercase tracking-widest block mb-2">Evento</label>
              <input 
                value={newTitle} 
                onChange={e => setNewTitle(e.target.value)}
                className="w-full bg-neutral-900 border-neutral-800 rounded-xl p-3 text-sm text-white focus:border-yellow-500 outline-none" 
                placeholder="Ex: Treino de Sabre, Prova Nacional..."
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] text-yellow-500 font-bold uppercase tracking-widest block mb-2">Data</label>
                <input 
                  type="date"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  className="w-full bg-neutral-900 border-neutral-800 rounded-xl p-3 text-sm text-white focus:border-yellow-500 outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-yellow-500 font-bold uppercase tracking-widest block mb-2">Distrito</label>
                <select 
                  value={newLocation}
                  onChange={e => setNewLocation(e.target.value)}
                  className="w-full bg-neutral-900 border-neutral-800 rounded-xl p-3 text-sm text-white focus:border-yellow-500 outline-none appearance-none"
                >
                  <option value="">Nacional (Sede)</option>
                  {PORTUGAL_DISTRICTS.map(d => (
                    <option key={d.name} value={d.name}>{d.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="text-[10px] text-yellow-500 font-bold uppercase tracking-widest block mb-2">Tipo</label>
              <select 
                value={newType}
                onChange={e => setNewType(e.target.value as any)}
                className="w-full bg-neutral-900 border-neutral-800 rounded-xl p-3 text-sm text-white focus:border-yellow-500 outline-none appearance-none"
              >
                <option value="treino">Treino</option>
                <option value="competição">Competição</option>
                <option value="estágio">Estágio</option>
                <option value="outro">Outro</option>
              </select>
            </div>
            <button type="submit" className="w-full py-3 bg-yellow-500 text-black font-bold uppercase tracking-widest text-[10px] rounded-xl mt-4">
              Adicionar Registro
            </button>
          </form>
        </motion.div>
      )}

      <div className="space-y-4">
        <h4 className="text-[10px] text-neutral-500 font-bold uppercase tracking-[0.2em] mb-2 px-2">Listagem de Eventos</h4>
        {events.length === 0 ? (
          <div className="card-clean border-neutral-800 p-8 text-center text-neutral-500 italic text-xs">
            Nenhum evento registrado ainda. Usa o botão + para planeares a tua época.
          </div>
        ) : (
          [...events].sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map((event) => (
            <div key={event.id} className="card-clean border-neutral-800 flex items-center justify-between p-4 group">
              <div className="flex items-center gap-4">
                <div className={cn(
                  "p-2 rounded-lg",
                  event.type === 'competição' ? "bg-red-500/10 text-red-500" :
                  event.type === 'treino' ? "bg-yellow-500/10 text-yellow-500" : "bg-neutral-800 text-neutral-400"
                )}>
                  {getEventIcon(event.type)}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest">{event.title}</h4>
                  <p className="text-[10px] text-neutral-500 uppercase">
                    {format(parseISO(event.date), 'dd/MM/yyyy')} — {event.type}
                    {event.location && <span className="text-brand-green ml-2">📍 {event.location}</span>}
                  </p>
                </div>
              </div>
              <button onClick={() => onRemoveEvent(event.id)} className="text-neutral-700 hover:text-red-500 transition-colors p-2">
                <Trash2 size={16} />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const CategoryDetailPage = ({ title, onBack }: { title: string, onBack: () => void }) => (
  <div className="min-h-screen bg-black flex flex-col pt-10 px-10">
    <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
      <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Voltar</span>
    </button>
    <h2 className="text-3xl font-serif text-white italic mb-8 uppercase tracking-tighter">{title}</h2>
    <div className="card-clean space-y-4">
      <p className="text-neutral-400 text-sm leading-relaxed">
        Bem-vindo à secção de {title}. Aqui encontrará informação detalhada e específica para esta fase de vida, desde nutrição a cuidados preventivos.
      </p>
      <div className="space-y-4 pt-4">
        {['Guia Rápido', 'Checklist Saúde', 'Nutrição Recomendada', 'Fórum Comunidade'].map((item) => (
          <button key={item} className="w-full py-4 text-left border-b border-neutral-800 text-xs text-white flex justify-between items-center group hover:bg-neutral-900 px-2 transition-all">
            <span>{item}</span>
            <ChevronRight size={14} className="text-brand-green" />
          </button>
        ))}
      </div>
    </div>
  </div>
);

const CuraePage = ({ onNavigate }: { onNavigate: (s: any) => void }) => (
  <div className="min-h-screen bg-black flex flex-col items-center pt-10 px-10">
    <button onClick={() => onNavigate('home')} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
      <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Voltar</span>
    </button>
    <PrototypeLogo size="sm" />
    <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-12">Categorias Saúde</h2>
    <div className="w-full space-y-4">
      {['Materna', 'Idoso', 'Adulto', 'Criança', 'Recém-nascido'].map((stage) => (
        <button 
          key={stage} 
          onClick={() => onNavigate(`curae-${stage.toLowerCase()}`)}
          className="btn-secondary flex justify-between px-6 items-center"
        >
          <span>{stage}</span>
          <ChevronRight size={16} />
        </button>
      ))}
    </div>
  </div>
);

const MotusPage = ({ onNavigate }: { onNavigate: (s: Section) => void }) => (
  <div className="min-h-screen bg-black flex flex-col pb-32">
    <PrototypeLogo header />
    
    <div className="px-10 pt-10">
      <button onClick={() => onNavigate('home')} className="self-start text-neutral-500 mb-8 flex items-center gap-2 active:scale-95 transition-transform">
        <ChevronLeft size={20} /> <span className="text-[10px] uppercase font-bold tracking-widest">Painel Principal</span>
      </button>
      
      <div className="flex flex-col items-center mb-16">
        <img src="/input_file_1.png" alt="Motus Logo" className="w-full max-w-[200px] object-contain" referrerPolicy="no-referrer" />
      </div>

      <div className="w-full space-y-6">
        <button 
          onClick={() => onNavigate('metrics')} 
          className="w-full py-5 bg-brand-green/80 hover:bg-brand-green text-black font-bold uppercase tracking-[0.4em] text-[10px] rounded-xl transition-all shadow-xl shadow-brand-green/10 active:scale-[0.98]"
        >
          Motus
        </button>
        <button 
          onClick={() => onNavigate('gladius-setup')} 
          className="w-full py-5 bg-brand-green/80 hover:bg-brand-green text-black font-bold uppercase tracking-[0.4em] text-[10px] rounded-xl transition-all shadow-xl shadow-brand-green/10 active:scale-[0.98]"
        >
          Curae Gladius
        </button>
      </div>

      <div className="mt-20 p-6 border border-neutral-900 bg-neutral-900/10 rounded-2xl text-center">
        <p className="text-[9px] text-neutral-500 uppercase tracking-widest mb-2 font-bold italic">Performance Ecosystem</p>
        <p className="text-[8px] text-neutral-700 uppercase leading-relaxed tracking-wider">
          Integrando saúde e esgrima num fluxo contínuo de dados e clareza.
        </p>
      </div>
    </div>
  </div>
);

const GladiusSetupPage = ({ onNext }: { onNext: (data: {weapon: Weapon, hand: Laterality}) => void }) => {
  const [weapon, setWeapon] = useState<Weapon>('sabre');
  const [hand, setHand] = useState<Laterality>('direito');

  return (
    <div className="min-h-screen bg-black flex flex-col pb-32">
      <PrototypeLogo header />
      
      <div className="px-10 pt-10">
        <div className="flex flex-col items-center mb-12">
          <img src="/input_file_0.png" alt="Gladius Logo" className="w-full max-w-[180px] object-contain" referrerPolicy="no-referrer" />
        </div>
        
        <div className="w-full space-y-10">
          <div className="space-y-4">
            <label className="text-[9px] text-neutral-500 font-bold uppercase tracking-[0.3em] px-1">Selecione Lateralidade</label>
            <div className="grid grid-cols-2 gap-4">
              {(['direito', 'esquerdo'] as Laterality[]).map((h) => (
                <button 
                  key={h}
                  onClick={() => setHand(h)}
                  className={cn(
                    "py-4 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all", 
                    hand === h ? "border-brand-green text-brand-green bg-brand-green/10 shadow-lg shadow-brand-green/5" : "border-neutral-900 text-neutral-500 bg-neutral-900/20"
                  )}
                >
                  {h}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[9px] text-neutral-500 font-bold uppercase tracking-[0.3em] px-1">Escolha a sua Arma</label>
            <div className="grid grid-cols-3 gap-2">
              {(['espada', 'sabre', 'florete'] as Weapon[]).map((w) => (
                <button 
                  key={w}
                  onClick={() => setWeapon(w)}
                  className={cn(
                    "py-4 rounded-xl border text-[9px] font-bold uppercase tracking-widest transition-all", 
                    weapon === w ? "border-brand-green text-brand-green bg-brand-green/10 shadow-lg shadow-brand-green/5" : "border-neutral-900 text-neutral-500 bg-neutral-900/20"
                  )}
                >
                  {w}
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={() => onNext({ weapon, hand })} 
            className="w-full py-5 bg-brand-green/80 hover:bg-brand-green text-black font-bold uppercase tracking-[0.4em] text-[10px] rounded-xl transition-all shadow-xl shadow-brand-green/30 mt-12 active:scale-[0.98]"
          >
            Confirmar e Entrar
          </button>
        </div>
      </div>
    </div>
  );
}

const GladiusPage = ({ weapon, onBack, onNavigate }: { weapon?: Weapon, onBack: () => void, onNavigate: (s: Section) => void }) => {
  const [showAddLog, setShowAddLog] = useState(false);
  const [stats] = useState({
    wins: 12,
    losses: 8,
    touchesScored: 142,
    touchesReceived: 110,
    attacks: 45,
    ripostes: 32,
    counters: 20,
    timePerTouch: 18.5, // average seconds per touch
  });

  const ios = (stats.touchesScored / (stats.touchesReceived || 1)).toFixed(2);
  const winRate = ((stats.wins / (stats.wins + stats.losses || 1)) * 100).toFixed(0);

  const radarData = [
    { subject: 'Ataque', A: 85, fullMark: 100 },
    { subject: 'Defesa', A: 70, fullMark: 100 },
    { subject: 'Velocidade', A: 90, fullMark: 100 },
    { subject: 'Tática', A: 65, fullMark: 100 },
    { subject: 'Endurance', A: 80, fullMark: 100 },
  ];

  return (
   <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="pb-24 px-10 bg-black min-h-screen"
    >
      <div className="flex justify-between items-center pt-10 mb-8">
        <button onClick={onBack} className="text-neutral-500 flex items-center gap-2">
          <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
        </button>
        <div className="flex gap-4">
          <button onClick={() => onNavigate('injuries')} className="text-red-500/80 flex items-center gap-2">
            <Activity size={18} /> <span className="text-[10px] uppercase font-bold tracking-widest">Lesões</span>
          </button>
          <button onClick={() => onNavigate('scouting')} className="text-neutral-500 flex items-center gap-2">
            <FileText size={18} /> <span className="text-[10px] uppercase font-bold tracking-widest">Scouting</span>
          </button>
        </div>
      </div>
      
      <header className="mb-10">
        <p className="text-brand-green font-bold text-[10px] uppercase tracking-[0.4em] mb-2">Performance {weapon || 'Sabre'}</p>
        <h2 className="text-4xl font-serif text-white italic tracking-tighter leading-tight">Análise <span className="text-brand-green italic">Gladius</span></h2>
      </header>

      <div className="space-y-6">
        {/* Radar Chart Section */}
        <div className="card-clean bg-neutral-900/30 border-neutral-800/50 h-56 flex flex-col items-center justify-center py-2 overflow-hidden">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="60%" data={radarData}>
              <PolarGrid stroke="#333" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#666', fontSize: 10 }} />
              <Radar
                name="Performance"
                dataKey="A"
                stroke="#6db278"
                fill="#6db278"
                fillOpacity={0.4}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => onNavigate('metrics')} className="card-clean flex flex-col items-center justify-center p-4 gap-2 hover:bg-neutral-900 transition-all border-neutral-800">
            <Video size={20} className="text-brand-green" />
            <span className="text-[9px] uppercase font-bold text-neutral-400">Análise Vídeo</span>
          </button>
          <button onClick={() => onNavigate('scouting')} className="card-clean flex flex-col items-center justify-center p-4 gap-2 hover:bg-neutral-900 transition-all border-neutral-800">
            <Target size={20} className="text-brand-green" />
            <span className="text-[9px] uppercase font-bold text-neutral-400">Tactical LEF</span>
          </button>
        </div>

        {/* Detailed Metrics Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="card-clean py-4 px-2 flex flex-col items-center">
            <span className="text-[8px] uppercase text-neutral-500 mb-1">Win Rate</span>
            <span className="text-xl font-bold text-white">{winRate}%</span>
          </div>
          <div className="card-clean py-4 px-2 flex flex-col items-center">
            <span className="text-[8px] uppercase text-neutral-500 mb-1">Ratio (IoS)</span>
            <span className="text-xl font-bold text-brand-green">+{ios}</span>
          </div>
          <div className="card-clean py-4 px-2 flex flex-col items-center">
             <span className="text-[8px] uppercase text-neutral-500 mb-1">S/Touch</span>
             <span className="text-xl font-bold text-neutral-300">{stats.timePerTouch}s</span>
          </div>
        </div>

        {/* Tactical Distribution */}
        <div className="card-clean border-neutral-800/50">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Distribuição Táctica</h3>
            <span className="text-[9px] text-brand-green font-bold">SMARTFENCER Enabled</span>
          </div>
          <div className="space-y-4">
            {[
              { label: 'Ataques Diretos', value: stats.attacks, color: 'bg-brand-green' },
              { label: 'Parada-Resposta', value: stats.ripostes, color: 'bg-white' },
              { label: 'Contra-Ataques', value: stats.counters, color: 'bg-neutral-600' }
            ].map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase tracking-tighter">
                  <span className="text-neutral-400">{item.label}</span>
                  <span className="text-white font-bold">{item.value} / 100</span>
                </div>
                <div className="h-1 bg-neutral-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(item.value / 100) * 100}%` }}
                    className={cn("h-full", item.color)} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bout Log Action */}
        <button 
          onClick={() => setShowAddLog(true)}
          className="btn-prototype flex items-center justify-center gap-3"
        >
          <Plus size={16} /> Novo Registo de Assalto
        </button>

        {/* History */}
        <div className="space-y-4">
          <h3 className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest border-b border-neutral-800 pb-2">Assaltos Recentes</h3>
          {[
            { opponent: 'Clube Albi', score: '15-12', result: 'W', time: '12m 4s', weapon: 'Sabre' },
            { opponent: 'Treino Técnico', score: '5-3', result: 'W', time: '4m 12s', weapon: 'Sabre' },
            { opponent: 'Competição Reg', score: '11-15', result: 'L', time: '18m 30s', weapon: 'Sabre' }
          ].map((bout, i) => (
            <div key={i} className="card-clean p-4 flex justify-between items-center group bg-neutral-900/20 active:scale-[0.98] transition-all">
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shadow-lg",
                  bout.result === 'W' ? "bg-brand-green text-black" : "bg-neutral-800 text-neutral-500"
                )}>
                  {bout.result}
                </div>
                <div>
                  <p className="text-sm font-bold text-white mb-0.5">{bout.opponent}</p>
                  <div className="flex items-center gap-2">
                    <Clock size={10} className="text-neutral-600" />
                    <span className="text-[9px] uppercase text-neutral-500 tracking-widest">{bout.time}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-base font-bold text-white tracking-widest">{bout.score}</p>
                <div className="flex items-center gap-1 justify-end mt-1">
                  <span className="text-[8px] text-neutral-600 uppercase font-bold">{bout.weapon}</span>
                  <ChevronRight size={12} className="text-neutral-800" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Log Modal (same as before but slightly enhanced) */}
      <AnimatePresence>
        {showAddLog && (
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed inset-0 z-[60] bg-black p-10 pt-20 overflow-y-auto"
          >
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-serif italic">Novo Assalto</h2>
              <button onClick={() => setShowAddLog(false)}><ChevronLeft size={24} className="text-neutral-500" /></button>
            </div>
            
            <div className="space-y-8 pb-20">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-neutral-500">Toques Dados</label>
                  <input type="number" className="w-full card-clean py-4 text-center text-3xl font-bold bg-neutral-900 focus:border-brand-green border-neutral-800" placeholder="0" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase text-neutral-500">Toques Sofridos</label>
                  <input type="number" className="w-full card-clean py-4 text-center text-3xl font-bold bg-neutral-900 focus:border-red-500 border-neutral-800" placeholder="0" />
                </div>
              </div>
              
              <div className="space-y-4">
                <label className="text-[10px] uppercase text-neutral-500 font-bold">Acção Dominante</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Ataque Direto', 'Parada-Resposta', 'Contra-Ataque', 'Remise', 'Remise em T2', 'Fleche'].map(action => (
                    <button key={action} className="py-4 px-2 border border-neutral-800 rounded-xl text-[9px] uppercase font-bold text-neutral-500 hover:border-brand-green hover:text-brand-green transition-all">
                      {action}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase text-neutral-500">Duração Combate (segundos)</label>
                <input type="number" className="w-full card-clean py-4 text-center text-xl bg-neutral-900 border-neutral-800" placeholder="180" />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase text-neutral-500 font-bold">Scouting & Notas Táticas</label>
                <textarea 
                  className="w-full card-clean bg-neutral-900 h-32 text-sm text-neutral-300 focus:border-brand-green border-neutral-800 p-4" 
                  placeholder="Arquétipo do oponente, padrões de ataque identificados, erros técnicos..." 
                />
              </div>

              <div className="flex gap-4 pt-10">
                <button onClick={() => setShowAddLog(false)} className="flex-1 btn-prototype shadow-brand-green/20 shadow-lg">Salvar Assalto</button>
                <button onClick={() => setShowAddLog(false)} className="px-6 py-4 border border-neutral-800 rounded-xl text-neutral-500 font-bold uppercase text-[10px]">Cancelar</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

const ScoutingPage = ({ onBack }: { onBack: () => void }) => {
  const [selectedOpponent, setSelectedOpponent] = useState<number | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const opponents = [
    { 
      id: 1, 
      name: 'João Silva', 
      club: 'AAE', 
      archetype: 'Defensivo/Counter', 
      risk: 'Fundo da pista',
      bouts: '12 - 10 (Vitória)',
      tactic: 'Ataque imediato na linha de fundo, forçar erro na preparação.',
      strengths: ['Velocidade de braço', 'Parada de 4ª'],
      weaknesses: ['Equilíbrio em recuo', 'Fintas longas']
    },
    { 
      id: 2, 
      name: 'Marta Ferreira', 
      club: 'SCP', 
      archetype: 'Agressivo/Blade Action', 
      risk: 'Fintas em fente', 
      bouts: '8 - 15 (Derrota)',
      tactic: 'Recuo com paradas de quarta, evitar contacto de lâmina prematuro.',
      strengths: ['Pressão constante', 'Flecha explosiva'],
      weaknesses: ['Gestão de distância', 'Segunda intenção']
    }
  ];

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
        <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Hub</span>
      </button>
      <SectionHero title={<>Relatórios <span className="text-brand-green">Scouting</span></>} subtitle="Vencer pelo Cérebro" icon={Target} color="text-brand-green" />
      
      <div className="space-y-4">
        {opponents.map((opp) => (
          <div key={opp.id} className="card-clean border-neutral-800 bg-neutral-900/20 overflow-hidden">
            <button 
              onClick={() => setSelectedOpponent(selectedOpponent === opp.id ? null : opp.id)}
              className="w-full p-4 flex items-center justify-between group"
            >
              <div className="flex items-center gap-4 text-left">
                <div className="w-10 h-10 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-brand-green">
                  <User size={20} />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-widest">{opp.name}</h3>
                  <p className="text-[9px] text-neutral-500 uppercase">{opp.club} • {opp.archetype}</p>
                </div>
              </div>
              <ChevronRight className={cn("text-neutral-700 transition-transform", selectedOpponent === opp.id && "rotate-90")} size={16} />
            </button>

            <AnimatePresence>
              {selectedOpponent === opp.id && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4 border-t border-neutral-800/50 pt-4 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-brand-green/5 rounded-lg border border-brand-green/10">
                      <p className="text-[8px] text-brand-green font-bold uppercase mb-1">Pontos Fortes</p>
                      <ul className="text-[9px] text-neutral-400">
                        {opp.strengths?.map(s => <li key={s}>• {s}</li>)}
                      </ul>
                    </div>
                    <div className="p-2 bg-red-500/5 rounded-lg border border-red-500/10">
                      <p className="text-[8px] text-red-500 font-bold uppercase mb-1">Pontos Fracos</p>
                      <ul className="text-[9px] text-neutral-400">
                        {opp.weaknesses?.map(w => <li key={w}>• {w}</li>)}
                      </ul>
                    </div>
                  </div>

                  <div className="bg-neutral-900 p-3 rounded-xl border border-neutral-800">
                    <p className="text-[8px] text-neutral-500 uppercase font-bold mb-1 tracking-widest text-center">Protocolo Tático Recomendado</p>
                    <p className="text-[10px] text-neutral-300 italic leading-relaxed text-center font-serif">
                      "{opp.tactic}"
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-6 border-t border-neutral-900">
        <button 
          onClick={() => setShowAdd(true)}
          className="w-full py-4 border border-brand-green/30 text-brand-green rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-brand-green/5 transition-all flex items-center justify-center gap-2"
        >
          <Plus size={14} /> Novo Adversário
        </button>
      </div>

      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6 text-center">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-8"
            >
              <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Registo Scouting</h3>
              <div className="space-y-4 mb-8">
                <input className="w-full bg-black border border-neutral-800 rounded-xl p-4 text-xs text-white outline-none" placeholder="Nome do Atleta" />
                <input className="w-full bg-black border border-neutral-800 rounded-xl p-4 text-xs text-white outline-none" placeholder="Clube" />
              </div>
              <div className="flex gap-4">
                <button onClick={() => setShowAdd(false)} className="flex-1 py-4 border border-neutral-800 text-neutral-500 font-bold uppercase tracking-widest text-[10px] rounded-xl">Cancelar</button>
                <button onClick={() => setShowAdd(false)} className="flex-1 py-4 bg-brand-green text-black font-bold uppercase tracking-widest text-[10px] rounded-xl">Gravar</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const InjuriesPage = ({ onBack, onNavigate }: { onBack: () => void, onNavigate: (s: Section) => void }) => {
  const [activeInjury, setActiveInjury] = useState<number | null>(null);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    let interval: any;
    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else if (timer === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timer]);

  const startRiceTimer = () => {
    setTimer(20 * 60); // 20 minutes
    setIsTimerRunning(true);
  };

  const injuries = [
    {
      name: "Contratura Muscular",
      freq: "28-45%",
      area: "Coxa posterior, panturrilha, abdutores",
      symptoms: "Dor súbita, rigidez muscular, limitação de movimento",
      prevention: "Aquecimento dinâmico (10-15 min), alongamentos pós-treino"
    },
    {
      name: "Espasmo Muscular (Cãibra)",
      freq: "28%",
      area: "Pernas, pés",
      symptoms: "Contração involuntária dolorosa, 'nó' no músculo",
      prevention: "Hidratação (2-3L/dia), eletrólitos, pausas"
    },
    {
      name: "Tendinite",
      freq: "18%",
      area: "Ombro, punho, tendão de Aquiles",
      symptoms: "Dor progressiva, inchaço leve, crepitação",
      prevention: "Fortalecimento assimétrico, técnica de grip, descanso"
    },
    {
      name: "Entorse (Torção)",
      freq: "Comum em fintas",
      area: "Tornozelo, joelho",
      symptoms: "Inchaço rápido, instabilidade, hematoma",
      prevention: "Treino proprioceptivo, calçado com suporte"
    },
    {
      name: "Lombalgia",
      freq: "15-20%",
      area: "Região lombar",
      symptoms: "Dor irradiada, rigidez matinal, rotações difíceis",
      prevention: "Core assimétrico (planks laterais), postura neutra"
    }
  ];

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
        <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Voltar</span>
      </button>
      
      <header className="mb-10">
        <div className="flex items-center gap-3 mb-2">
          <Activity className="text-red-500" size={24} />
          <p className="text-red-500 font-bold text-[10px] uppercase tracking-[0.4em]">Prevenção & Saúde</p>
        </div>
        <h2 className="text-4xl font-serif text-white italic tracking-tighter">Guia de <span className="text-red-500">Lesões</span></h2>
      </header>

      <button 
        onClick={() => onNavigate('check-prevention')}
        className="w-full card-clean border-brand-green/30 bg-brand-green/5 p-6 mb-10 flex justify-between items-center group transition-all active:scale-95"
      >
        <div>
          <h3 className="text-brand-green font-bold text-xs uppercase tracking-widest mb-1">Checklist de Prevenção</h3>
          <p className="text-[10px] text-neutral-500 uppercase">Verifica o teu risco hoje</p>
        </div>
        <ArrowRight size={20} className="text-brand-green group-hover:translate-x-2 transition-transform" />
      </button>

      <section className="space-y-4 mb-12">
        <h3 className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest border-b border-neutral-800 pb-2">Lesões Comuns</h3>
        {injuries.map((ij, i) => (
          <div key={i} className="card-clean border-neutral-800 p-0 overflow-hidden transition-all">
            <button 
              onClick={() => setActiveInjury(activeInjury === i ? null : i)}
              className="w-full p-4 flex justify-between items-center text-left"
            >
              <div>
                <p className="text-white font-bold text-sm">{ij.name}</p>
                <p className="text-[9px] text-neutral-500 uppercase tracking-widest mt-1">Risco: {ij.freq}</p>
              </div>
              <Plus size={16} className={cn("text-neutral-500 transition-transform", activeInjury === i && "rotate-45")} />
            </button>
            <AnimatePresence>
              {activeInjury === i && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4 space-y-4 border-t border-neutral-800 pt-4"
                >
                  <div className="space-y-1">
                    <p className="text-[9px] text-neutral-600 font-bold uppercase tracking-widest">Local Afetado</p>
                    <p className="text-xs text-neutral-400">{ij.area}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[9px] text-red-500/70 font-bold uppercase tracking-widest">Sintomas</p>
                    <p className="text-xs text-neutral-400">{ij.symptoms}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[9px] text-brand-green/70 font-bold uppercase tracking-widest">Prevenção</p>
                    <p className="text-xs text-neutral-400">{ij.prevention}</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </section>

      <section className="card-clean border-red-500/20 bg-red-500/5 mb-12">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="text-red-500" size={18} />
          <h3 className="text-xs font-bold text-white uppercase tracking-widest">Protocolo RICE</h3>
        </div>
        <p className="text-[10px] text-neutral-400 mb-4 leading-relaxed italic">
          (R)epouso, (I)ce/Gelo, (C)ompressão, (E)levação. Use nas primeiras 48h de lesão aguda.
        </p>
        <div className="bg-black/50 rounded-xl p-6 text-center mb-6">
          <p className="text-[10px] text-neutral-500 uppercase mb-2">Timer de Gelo Recomendado (20 min)</p>
          <p className="text-4xl font-mono font-bold text-white mb-4">{formatTime(timer)}</p>
          <button 
            onClick={isTimerRunning ? () => setIsTimerRunning(false) : startRiceTimer}
            className={cn("px-8 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all", isTimerRunning ? "bg-red-500 text-white" : "bg-white text-black")}
          >
            {isTimerRunning ? 'Pausar' : timer > 0 ? 'Continuar' : 'Iniciar Timer'}
          </button>
        </div>
      </section>

      <div className="card-clean bg-neutral-900 border-neutral-800 text-center py-6">
        <p className="text-[8px] text-neutral-500 uppercase px-4 leading-relaxed">
          Disclaimer: Esta secção é informativa. Em caso de dor incapacitante ou persistente, consulte sempre um médico ou fisioterapeuta especializado em desporto.
        </p>
      </div>
    </div>
  );
};

const CheckPreventionPage = ({ onBack }: { onBack: () => void }) => {
  const [checked, setChecked] = useState<number[]>([]);
  const items = [
    { title: "Aquecimento Dinâmico", desc: "10-15 min de shadow fencing + mobilidade" },
    { title: "Hidratação", desc: "Já bebeste pelo menos 1.5L de água hoje?" },
    { title: "Equipamento", desc: "Máscara e luva estão em boas condições?" },
    { title: "Core e Postura", desc: "Fizeste pelo menos 5 min de core hoje?" },
    { title: "Recuperação", desc: "Dormiste pelo menos 7-8h na última noite?" }
  ];

  const handleCheck = (i: number) => {
    if (checked.includes(i)) setChecked(checked.filter(c => c !== i));
    else setChecked([...checked, i]);
  };

  const progress = (checked.length / items.length) * 100;

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2">
        <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Voltar</span>
      </button>
      <h2 className="text-3xl font-serif text-white italic mb-4">Checklist Diário</h2>
      <p className="text-[10px] text-neutral-500 uppercase tracking-widest mb-10">Prevenção Proativa</p>

      <div className="mb-10">
        <div className="flex justify-between items-end mb-2">
          <span className="text-[10px] text-brand-green font-bold uppercase tracking-widest">Progresso Proteção</span>
          <span className="text-xl font-serif text-white italic">{progress.toFixed(0)}%</span>
        </div>
        <div className="h-1 bg-neutral-900 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className="h-full bg-brand-green"
          />
        </div>
      </div>

      <div className="space-y-4">
        {items.map((item, i) => (
          <button 
            key={i} 
            onClick={() => handleCheck(i)}
            className={cn("w-full card-clean p-4 flex items-center gap-4 text-left transition-all", checked.includes(i) ? "border-brand-green/40 opacity-50" : "border-neutral-800")}
          >
            <div className={cn("w-6 h-6 rounded-lg border-2 flex items-center justify-center shrink-0", checked.includes(i) ? "bg-brand-green border-brand-green text-black" : "border-neutral-800")}>
              {checked.includes(i) && <ChevronRight size={16} className="rotate-90" />}
            </div>
            <div>
              <p className="text-xs font-bold text-white">{item.title}</p>
              <p className="text-[9px] text-neutral-500 uppercase mt-0.5">{item.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {progress === 100 && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-10 p-4 rounded-2xl bg-brand-green/20 border border-brand-green/30 text-center"
        >
          <p className="text-brand-green font-bold text-xs uppercase tracking-widest">Estás Pronto para Pista!</p>
          <p className="text-[9px] text-neutral-400 mt-1 italic uppercase">Risco de lesão minimizado para o treino de hoje.</p>
        </motion.div>
      )}
    </div>
  );
};

const MetricsPage = ({ events, profile, setProfile, biometrics, setBiometrics }: { 
  events: CalendarEvent[], 
  profile: any, 
  setProfile: (p: any) => void,
  biometrics: any[],
  setBiometrics: (b: any[]) => void
}) => {
  const [water, setWater] = useState(1.2);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [showAddBiometric, setShowAddBiometric] = useState(false);
  
  const athleteFile = [
    { label: 'Nome Completo', value: profile.nome, icon: User, key: 'nome' },
    { label: 'Data Nascimento', value: profile.dataNascimento, icon: Calendar, key: 'dataNascimento' },
    { label: 'Idade', value: profile.idade, icon: Activity, key: 'idade' },
    { label: 'Humor (Face)', value: profile.humor, icon: Smile, key: 'humor' },
    { label: 'Arma', value: profile.arma, icon: Sword, key: 'arma' },
    { label: 'Mão', value: profile.mao, icon: Activity, key: 'mao' },
    { label: 'Licença', value: profile.licenca, icon: FileText, key: 'licenca' }
  ];

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const calendarDays = eachDayOfInterval({ start: startDate, end: endDate });

  const getDayEvents = (day: Date) => {
    return events.filter(e => isSameDay(parseISO(e.date), day));
  };

  const handleAddBiometric = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const type = formData.get('type') as string;
    const value = formData.get('value') as string;
    const unit = type === 'Altura' ? 'm' : 'kg';
    
    setBiometrics([{
      type,
      value: `${value}${unit}`,
      date: format(new Date(), 'MMM yyyy', { locale: pt })
    }, ...biometrics]);
    setShowAddBiometric(false);
  };

  return (
    <div className="pb-24 px-10 bg-black min-h-screen relative">
      <header className="pt-10 mb-10">
        <p className="text-brand-green font-bold text-[10px] uppercase tracking-[0.4em] mb-2">Performance Geral</p>
        <h2 className="text-4xl font-serif text-white italic tracking-tighter">Métricas <span className="text-brand-green">Motus</span></h2>
      </header>
      
      <div className="space-y-6">
        {/* Ficha do Atleta */}
        <div className="card-clean border-neutral-800 bg-neutral-900/10 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <User className="text-brand-green" size={16} />
              <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Ficha do Atleta</span>
            </div>
            <button 
              onClick={() => setIsEditingProfile(!isEditingProfile)}
              className="text-[8px] font-bold text-neutral-500 uppercase tracking-widest hover:text-brand-green transition-colors"
            >
              {isEditingProfile ? 'Concluído' : 'Editar'}
            </button>
          </div>

          {isEditingProfile ? (
            <div className="grid grid-cols-1 gap-4">
              {athleteFile.map((item) => (
                <div key={item.key} className="space-y-1">
                  <label className="text-[8px] text-neutral-500 uppercase font-bold px-1">{item.label}</label>
                  <input 
                    type={item.key === 'dataNascimento' ? 'date' : 'text'} 
                    value={(profile as any)[item.key]}
                    onChange={(e) => setProfile({ ...profile, [item.key]: e.target.value })}
                    className="w-full bg-black border border-neutral-800 rounded-xl p-3 text-[10px] text-white focus:border-brand-green outline-none transition-all"
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {athleteFile.map((item, idx) => {
                const Icon = item.icon;
                const isFullName = item.key === 'nome';
                return (
                  <div 
                    key={item.label} 
                    className={cn(
                      "flex items-center gap-3 p-3 bg-black border border-neutral-800 rounded-xl cursor-pointer hover:border-neutral-600 transition-all active:scale-[0.98]",
                      isFullName && "col-span-2"
                    )}
                  >
                    <div className="p-2 bg-neutral-900 rounded-lg text-brand-green">
                      <Icon size={14} />
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[8px] text-neutral-500 uppercase font-medium truncate">{item.label}</p>
                      <p className="text-[10px] text-white font-bold truncate">{item.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Mood / Humor Selection */}
        <div className="card-clean border-neutral-800 bg-neutral-900/10 mb-6">
          <div className="flex items-center gap-2 mb-6">
            <Heart className="text-pink-500" size={16} />
            <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Estado de Humor (Hoje)</span>
          </div>
          <div className="flex justify-between items-center px-2">
            {[
              { icon: Frown, label: 'Baixo', color: 'text-red-500' },
              { icon: Meh, label: 'Neutro', color: 'text-neutral-500' },
              { icon: Smile, label: 'Bom', color: 'text-brand-green' },
              { icon: Award, label: 'Radiante', color: 'text-yellow-500' }
            ].map((mood, idx) => (
              <button 
                key={idx} 
                className={cn(
                  "flex flex-col items-center gap-2 group transition-all",
                  mood.label === 'Radiante' ? "scale-110" : "opacity-40 grayscale hover:opacity-100 hover:grayscale-0"
                )}
              >
                <div className={cn("p-3 rounded-2xl bg-black border border-neutral-800 group-active:scale-90 transition-transform shadow-lg", mood.label === 'Radiante' && "border-brand-green/30 bg-brand-green/5")}>
                  <mood.icon size={20} className={mood.color} />
                </div>
                <span className={cn("text-[8px] uppercase font-bold tracking-widest", mood.label === 'Radiante' ? "text-white" : "text-neutral-600")}>{mood.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Biometrics Tracking 3x Year */}
        <div className="card-clean border-neutral-800 bg-neutral-900/10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Scale className="text-brand-green" size={16} />
              <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Biometria (3x/Ano)</span>
            </div>
            <button 
              onClick={() => setShowAddBiometric(true)}
              className="p-1 hover:text-brand-green transition-colors"
            >
              <Plus size={14} className="text-neutral-500" />
            </button>
          </div>
          <div className="space-y-3">
            {biometrics.slice(0, 4).map((bio, idx) => (
              <div key={idx} className="flex justify-between items-center p-3 border border-neutral-900 bg-black rounded-xl">
                <div className="flex items-center gap-3">
                   {bio.type === 'Altura' ? <Ruler size={12} className="text-neutral-500" /> : <Scale size={12} className="text-neutral-500" />}
                   <span className="text-xs text-white font-bold">{bio.type}</span>
                </div>
                <div className="text-right">
                   <p className="text-xs text-brand-green font-bold leading-none">{bio.value}</p>
                   <p className="text-[8px] text-neutral-600 uppercase mt-1 tracking-widest">{bio.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add Biometric Modal */}
        <AnimatePresence>
          {showAddBiometric && (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 100 }}
                className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-8"
              >
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xs font-bold text-white uppercase tracking-widest">Nova Medição</h3>
                  <button onClick={() => setShowAddBiometric(false)} className="text-neutral-500"><X size={18} /></button>
                </div>
                
                <form onSubmit={handleAddBiometric} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[8px] text-neutral-500 uppercase font-bold px-1">Tipo de Medição</label>
                    <select name="type" className="w-full bg-black border border-neutral-800 rounded-xl p-4 text-xs text-white outline-none">
                      <option value="Peso">Peso (kg)</option>
                      <option value="Altura">Altura (m)</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-[8px] text-neutral-500 uppercase font-bold px-1">Valor</label>
                    <input 
                      name="value" 
                      type="number" 
                      step="0.01" 
                      placeholder="Ex: 75.5 ou 1.82"
                      required
                      className="w-full bg-black border border-neutral-800 rounded-xl p-4 text-xs text-white placeholder:text-neutral-700 outline-none" 
                    />
                  </div>

                  <button type="submit" className="w-full py-4 bg-brand-green text-black font-bold uppercase tracking-widest text-[10px] rounded-xl shadow-xl shadow-brand-green/10 active:scale-95 transition-all">
                    Guardar Medição
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Training & Meals Stats */}
        <div className="grid grid-cols-2 gap-4">
           <div className="card-clean p-4 border-neutral-800 bg-neutral-900/10">
              <div className="flex items-center gap-2 mb-3">
                <Dumbbell size={14} className="text-yellow-500" />
                <span className="text-[9px] font-bold text-neutral-500 uppercase">Treinos Semanal</span>
              </div>
              <p className="text-2xl font-bold text-white leading-none">4</p>
              <p className="text-[9px] text-neutral-500 mt-2">Méd. 90min / treino</p>
           </div>
           <div className="card-clean p-4 border-neutral-800 bg-neutral-900/10">
              <div className="flex items-center gap-2 mb-3">
                <Utensils size={14} className="text-orange-500" />
                <span className="text-[9px] font-bold text-neutral-500 uppercase">Refeições</span>
              </div>
              <p className="text-2xl font-bold text-white leading-none">5</p>
              <p className="text-[9px] text-neutral-500 mt-2">Diárias / Consistente</p>
           </div>
        </div>

        {/* Calendar (Relocated from Maps) */}
        <div className="card-clean border-neutral-800 bg-neutral-900/10">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">Calendário de Provas</h3>
            <div className="flex gap-2">
              <button onClick={() => setCurrentMonth(subMonths(currentMonth, 1))} className="p-1 hover:text-brand-green"><ChevronLeft size={16} /></button>
              <button onClick={() => setCurrentMonth(addMonths(currentMonth, 1))} className="p-1 hover:text-brand-green"><ChevronRight size={16} /></button>
            </div>
          </div>
          
          <div className="text-center mb-4">
            <span className="text-[10px] font-bold text-white uppercase tracking-widest">{format(currentMonth, 'MMMM yyyy', { locale: pt })}</span>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center mb-2">
            {['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].map(d => (
              <span key={d} className="text-[8px] text-neutral-600 font-bold">{d}</span>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, i) => {
              const dayEvents = getDayEvents(day);
              const isCurrentMonth = isSameMonth(day, monthStart);
              const isToday = isSameDay(day, new Date());
              return (
                <div 
                  key={i} 
                  className={cn(
                    "aspect-square rounded-lg flex flex-col items-center justify-center relative",
                    !isCurrentMonth && "opacity-10",
                    isToday && "bg-brand-green/20 ring-1 ring-brand-green/40"
                  )}
                >
                  <span className={cn("text-[9px] font-bold", isToday ? "text-brand-green" : "text-neutral-400")}>
                    {format(day, 'd')}
                  </span>
                  {dayEvents.length > 0 && (
                    <div className="flex gap-0.5 mt-0.5">
                      {dayEvents.map((e, idx) => (
                        <div key={idx} className={cn("w-1 h-1 rounded-full", e.type === 'competição' ? "bg-red-500" : "bg-yellow-500")} />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="card-clean">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">Hidratação</h3>
            <span className="text-2xl font-bold text-brand-green">{water.toFixed(1)}L</span>
          </div>
          <div className="relative h-1 bg-neutral-800 rounded-full overflow-hidden">
            <motion.div className="absolute inset-y-0 left-0 bg-brand-green" initial={{ width: 0 }} animate={{ width: `${Math.min(100, (water/3)*100)}%` }} />
          </div>
          <div className="flex justify-center gap-4 mt-6">
            <button onClick={() => setWater(prev => Math.max(0, prev - 0.2))} className="w-10 h-10 border border-neutral-800 rounded-full flex items-center justify-center text-white">-</button>
            <button onClick={() => setWater(prev => prev + 0.2)} className="w-10 h-10 border border-neutral-800 rounded-full flex items-center justify-center text-white">+</button>
          </div>
        </div>

        <div className="card-clean">
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-6">Sono</h3>
          <div className="flex justify-between text-center gap-4">
             <div className="flex-1 p-4 border border-neutral-800 rounded-xl">
               <p className="text-[9px] uppercase text-neutral-500">Horas</p>
               <p className="text-xl font-bold text-brand-green">7.5</p>
             </div>
             <div className="flex-1 p-4 border border-neutral-800 rounded-xl">
               <p className="text-[9px] uppercase text-neutral-500">Qualidade</p>
               <p className="text-xl font-bold text-brand-green">Boa</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const MenuPage = ({ onNavigate }: { onNavigate: (s: Section) => void }) => {
  const menuItems = [
    { id: 'planning', label: 'Agenda & Provas', icon: Calendar, color: 'text-yellow-500' },
    { id: 'metrics', label: 'Métricas & Saúde', icon: Activity, color: 'text-brand-green' },
    { id: 'nutrition', label: 'Nutrição', icon: Apple, color: 'text-orange-500' },
    { id: 'recovery', label: 'Sono & Recuperação', icon: Moon, color: 'text-blue-500' },
    { id: 'progress', label: 'Metas & Medalhas', icon: Trophy, color: 'text-yellow-400' },
    { id: 'scouting', label: 'Scouting Adversários', icon: Target, color: 'text-brand-green' },
    { id: 'mindset', label: 'Mindset & Foco', icon: Brain, color: 'text-purple-400' },
  ];

  return (
    <div className="min-h-screen bg-black pt-20 px-10 pb-32">
       <SectionHero title={<>Menu <span className="text-brand-green">Hub</span></>} subtitle="Atalhos Rápidos" icon={Menu} />
       
       <div className="grid grid-cols-1 gap-4">
         {menuItems.map((item) => (
           <button 
             key={item.id}
             onClick={() => onNavigate(item.id as Section)}
             className="flex items-center justify-between p-5 card-clean border-neutral-900 bg-neutral-900/10 active:scale-[0.98] transition-all group"
           >
             <div className="flex items-center gap-4">
               <div className={cn("p-2 bg-black rounded-xl border border-neutral-800", item.color)}>
                 <item.icon size={20} />
               </div>
               <span className="text-xs font-bold text-white uppercase tracking-widest">{item.label}</span>
             </div>
             <ChevronRight className="text-neutral-700 group-hover:text-brand-green transition-colors" size={16} />
           </button>
         ))}
       </div>

       <button 
         className="w-full mt-12 py-4 border border-neutral-800 text-neutral-500 text-[10px] font-bold uppercase tracking-[0.4em] rounded-xl"
         onClick={() => onNavigate('home')}
       >
         Voltar ao Início
       </button>
    </div>
  );
};

const ProgressPage = ({ onBack }: { onBack: () => void }) => {
  const [goals] = useState<Goal[]>([
    { id: '1', title: 'Melhorar Parry-Riposte', target: '90% Sucesso', deadline: 'Jun 2024', progress: 75 },
    { id: '2', title: 'Aumento de Explosão', target: '+10% Velocidade', deadline: 'Ago 2024', progress: 40 },
  ]);

  const [achievements] = useState<Achievement[]>([
    { id: 'a1', title: 'Combatente Nato', description: 'Realizou 50 bouts treinais em 1 mês.', date: 'Mar 2024', icon: '⚔️', type: 'medal' },
    { id: 'a2', title: 'Hydration Master', description: 'Consistência de 2L/dia por 2 semanas.', date: 'Fev 2024', icon: '💧', type: 'milestone' },
    { id: 'a3', title: 'Espírito de Equipa', description: 'Destaque no último estágio.', date: 'Jan 2024', icon: '🤝', type: 'congratulations' },
  ]);

  return (
    <div className="min-h-screen bg-black flex flex-col pt-10 px-10 pb-32 overflow-y-auto font-sans">
      <button onClick={onBack} className="self-start text-neutral-500 mb-8 flex items-center gap-2 active:scale-95 transition-transform">
        <ChevronLeft size={20} /> <span className="text-[10px] uppercase font-bold tracking-widest">Painel</span>
      </button>
      <SectionHero title={<>Metas & <span className="text-yellow-500">Distinções</span></>} subtitle="O teu percurso" icon={Trophy} color="text-yellow-500" />

      <div className="space-y-8">
        <div>
          <header className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Target className="text-brand-green" size={14} />
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Metas Estratégicas</span>
            </div>
            <button className="text-[8px] font-bold text-brand-green uppercase tracking-widest hover:underline">+ Nova Meta</button>
          </header>
          <div className="space-y-4">
            {goals.map(goal => (
              <div key={goal.id} className="card-clean border-neutral-800 bg-neutral-900/10">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-tight">{goal.title}</h4>
                    <p className="text-[9px] text-neutral-500 uppercase mt-0.5 tracking-tighter">Target: {goal.target}</p>
                  </div>
                  <span className="text-[10px] text-brand-green font-bold">{goal.progress}%</span>
                </div>
                <div className="h-1 bg-neutral-900 rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${goal.progress}%` }} className="h-full bg-brand-green shadow-xl shadow-brand-green/20" />
                </div>
                <div className="flex justify-between items-center mt-3">
                   <p className="text-[8px] text-neutral-700 uppercase tracking-tighter">Fim em: {goal.deadline}</p>
                   <TrendingUp size={10} className="text-brand-green opacity-50" />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <header className="flex items-center gap-2 mb-6">
            <Medal className="text-yellow-500" size={14} />
            <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Conquistas & "Medalhas"</span>
          </header>
          <div className="grid grid-cols-1 gap-4">
            {achievements.map((ach, idx) => (
              <motion.div 
                key={ach.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="flex items-center gap-4 p-4 card-clean border-neutral-900/50 bg-yellow-500/[0.03] relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-2 opacity-5">
                  <Award size={48} className="text-yellow-500 rotate-12" />
                </div>
                <div className="w-14 h-14 rounded-2xl bg-neutral-900/50 border border-neutral-800 flex items-center justify-center text-3xl shadow-inner shrink-0 scale-90">
                  {ach.icon}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs font-bold text-white uppercase tracking-tight">{ach.title}</h4>
                  </div>
                  <p className="text-[10px] text-neutral-500 leading-relaxed mt-1 tracking-tight">{ach.description}</p>
                  <p className="text-[8px] text-yellow-500/60 font-bold uppercase mt-2 tracking-widest">{ach.date}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- MAIN APP ---

export default function App() {
  const [section, setSection] = useState<Section>('onboarding');
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<UserRole>('atleta');
  const [gdprAccepted, setGdprAccepted] = useState(false);
  const [gladiusSetup, setGladiusSetup] = useState<{weapon: Weapon, hand: Laterality} | null>(null);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [profile, setProfile] = useState({
    nome: 'André Martins',
    dataNascimento: '12/05/2007',
    idade: '17 Anos',
    humor: 'Bom',
    arma: 'Sabre',
    mao: 'Direito',
    licenca: 'FPF 1234'
  });
  const [biometrics, setBiometrics] = useState([
    { type: 'Altura', value: '1.82m', date: 'Abr 2024' },
    { type: 'Peso', value: '74.2kg', date: 'Abr 2024' },
    { type: 'Altura', value: '1.81m', date: 'Jan 2024' },
    { type: 'Peso', value: '73.5kg', date: 'Jan 2024' },
  ]);

  const handleAddEvent = (eventData: Omit<CalendarEvent, 'id'>) => {
    const newEvent: CalendarEvent = {
      ...eventData,
      id: Math.random().toString(36).substr(2, 9)
    };
    setEvents(prev => [...prev, newEvent]);
  };

  const handleRemoveEvent = (id: string) => {
    setEvents(prev => prev.filter(e => e.id !== id));
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        if (!gdprAccepted) setSection('gdpr');
        else setSection('home');
      }
    });
    return () => unsubscribe();
  }, [gdprAccepted]);

  const handleSignIn = async () => {
    try {
      await signIn();
    } catch (e) {
      console.error(e);
    }
  };

  const handleSignOut = () => signOut(auth);

  const renderContent = () => {
    if (section.startsWith('curae-')) {
      const title = section.split('-')[1].charAt(0).toUpperCase() + section.split('-')[1].slice(1);
      return <CategoryDetailPage title={title} onBack={() => setSection('curae')} />;
    }

    switch (section) {
      case 'onboarding': return <OnboardingPage onNext={() => setSection('login')} />;
      case 'login': return <LoginPage onLogin={handleSignIn} onRoleChange={(r) => setRole(r)} />;
      case 'gdpr': return <GDPRPage onAccept={() => { setGdprAccepted(true); setSection('home'); }} />;
      case 'mindset': return <MindsetPage onBack={() => setSection('home')} />;
      case 'nutrition': return <NutritionPage onBack={() => setSection('home')} />;
      case 'recovery': return <RecoveryPage onBack={() => setSection('home')} />;
      case 'health': return <InjuriesPage onBack={() => setSection('home')} onNavigate={setSection} />;
      case 'performance': return <GladiusPage onBack={() => setSection('home')} onNavigate={setSection} />;
      case 'menu': return <MenuPage onNavigate={setSection} />;
      case 'progress': return <ProgressPage onBack={() => setSection('menu')} />;
      case 'young-athletes': return (
        <div className="p-10 pt-20">
          <button onClick={() => setSection('home')} className="text-neutral-500 mb-8 flex items-center gap-2">
            <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
          </button>
          <SectionHero title={<>Jovens <span className="text-sky-400">Atletas</span></>} subtitle="Desenvolvimento" icon={Baby} color="text-sky-400" />
          <div className="card-clean border-neutral-800 p-8 text-center text-neutral-500 italic">
            Conteúdo em desenvolvimento para crescimento, gestão escolar e dicas para pais.
          </div>
        </div>
      );
      case 'planning': return (
        <PlanningPage 
          onBack={() => setSection('home')} 
          events={events} 
          onAddEvent={handleAddEvent} 
          onRemoveEvent={handleRemoveEvent}
        />
      );
      case 'parents': return (
        <div className="p-10 pt-20">
          <button onClick={() => setSection('home')} className="text-neutral-500 mb-8 flex items-center gap-2">
            <ChevronLeft size={20} /> <span className="text-xs uppercase font-bold tracking-widest">Painel</span>
          </button>
          <SectionHero title={<>Área dos <span className="text-brand-green">Pais</span></>} subtitle="Apoio & Mentoria" icon={Users} />
          <div className="card-clean border-neutral-800 p-8 text-center text-neutral-500 italic">
             Dicas sobre como apoiar sem pressionar e sinais de alerta para os filhos.
          </div>
        </div>
      );
      case 'home': return <HomePage onNavigate={setSection} role={role} userName={profile.nome} />;
      case 'curae': return <CuraePage onNavigate={setSection} />;
      case 'motus': return <MotusPage onNavigate={setSection} />;
      case 'gladius-setup': return <GladiusSetupPage onNext={(data) => { setGladiusSetup(data); setSection('gladius'); }} />;
      case 'gladius': return <GladiusPage weapon={gladiusSetup?.weapon} onBack={() => setSection('motus')} onNavigate={setSection} />;
      case 'scouting': return <ScoutingPage onBack={() => setSection('gladius')} />;
      case 'injuries': return <InjuriesPage onBack={() => setSection('gladius')} onNavigate={setSection} />;
      case 'check-prevention': return <CheckPreventionPage onBack={() => setSection('injuries')} />;
      case 'metrics': return <MetricsPage events={events} profile={profile} setProfile={setProfile} biometrics={biometrics} setBiometrics={setBiometrics} />;
      case 'profile': return <MetricsPage events={events} profile={profile} setProfile={setProfile} biometrics={biometrics} setBiometrics={setBiometrics} />;
      default: return <HomePage onNavigate={setSection} role={role} userName={profile.nome} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <motion.div 
          animate={{ opacity: [0, 1, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          className="text-brand-green font-bold tracking-widest"
        >
          CURAE
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black font-sans selection:bg-brand-green/30">
      <div className="max-w-md mx-auto min-h-screen bg-black relative pb-24">
        <main className="relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={section}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.3 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </main>

        {!['onboarding', 'login'].includes(section) && (
          <BottomNav current={section} onChange={setSection} />
        )}
      </div>
    </div>
  );
}
